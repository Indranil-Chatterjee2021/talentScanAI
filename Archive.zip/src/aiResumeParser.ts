import { GoogleGenerativeAI } from '@google/generative-ai';
import { Candidate, RecommendationType } from './CustomerSuccessManager';

// AI-powered resume parser using Google Generative AI
export class AIResumeParser {
  private static instance: AIResumeParser;
  private genAI: GoogleGenerativeAI | null = null;
  private model: any = null;

  private constructor() {
    this.initializeAI();
  }

  static getInstance(): AIResumeParser {
    if (!AIResumeParser.instance) {
      AIResumeParser.instance = new AIResumeParser();
    }
    return AIResumeParser.instance;
  }

  private initializeAI() {
    try {
      // For demo purposes, we'll use a mock API key
      // In production, this should come from environment variables
      const apiKey = process.env.REACT_APP_GOOGLE_AI_API_KEY || 'demo-mode';
      
      if (apiKey === 'demo-mode') {
  
        this.genAI = null;
      } else {
        this.genAI = new GoogleGenerativeAI(apiKey);
        this.model = this.genAI.getGenerativeModel({ model: 'gemini-pro' });

      }
    } catch (error) {
      
      this.genAI = null;
    }
  }

  async parseResume(filename: string, extractedText: string, jobDescription: { mustHave: string; niceToHave: string }): Promise<Candidate> {


    // If AI is not available, use enhanced rule-based parsing
    if (!this.genAI || !this.model) {

      return this.enhancedRuleBasedParsing(filename, extractedText, jobDescription);
    }

    try {
      // Create structured prompt for AI
      const prompt = this.createExtractionPrompt(filename, extractedText, jobDescription);
      
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const aiResult = response.text();
      
      // Parse AI response and create candidate
      return this.parseAIResponse(aiResult, filename, jobDescription);
      
          } catch (error) {
        return this.enhancedRuleBasedParsing(filename, extractedText, jobDescription);
      }
  }

  private createExtractionPrompt(filename: string, text: string, jd: { mustHave: string; niceToHave: string }): string {
    return `
You are an expert resume parser. Extract the following information from this resume text and return it as a JSON object.

FILENAME: ${filename}

JOB REQUIREMENTS:
- Must Have Skills: ${jd.mustHave}
- Nice to Have Skills: ${jd.niceToHave}

RESUME TEXT:
${text.substring(0, 3000)} // Limit text to avoid token limits

Extract and return ONLY a JSON object with this exact structure:
{
  "name": "Full name of the person (from filename if text is unclear)",
  "location": "City, State/Country (or 'Location not specified')",
  "currentRole": "Current job title",
  "currentCompany": "Current company name",
  "experiences": [
    {
      "role": "Specific job title from resume",
      "company": "Actual company name from resume", 
      "period": "Actual dates from resume (e.g., '2020 - 2023' or 'Jan 2020 - Present')"
    }
  ],
  "skills": ["skill1", "skill2", "skill3"],
  "strengths": ["strength based on JD match", "relevant experience"],
  "weaknesses": ["missing skills from JD", "areas for improvement"],
  "score": 7.5,
  "recommendation": "approve|hold|reject"
}

IMPORTANT RULES:
1. If text is corrupted/unclear, use the filename for the name
2. Extract REAL company names, job titles, and dates from the resume text
3. Do NOT use generic placeholders like "Technology Company" or "2021 - Present"
4. Look for actual company names (e.g., TCS, Infosys, Google, Microsoft, etc.)
5. Extract real job titles (e.g., "Senior Software Engineer", "Frontend Developer")
6. Find actual employment dates from the resume
7. Focus on skills that match the job requirements
8. Score based on how well skills match must-have requirements (1-10)
9. Include only real, relevant strengths and weaknesses
10. Recommendation: approve (8+ score), hold (6-7.9), reject (<6)
11. Return ONLY the JSON object, no other text
`;
  }

  private parseAIResponse(aiResponse: string, filename: string, jd: { mustHave: string; niceToHave: string }): Candidate {
    try {
      // Clean up the AI response to extract JSON
      let jsonString = aiResponse.trim();
      
      // Remove any markdown formatting
      jsonString = jsonString.replace(/```json/g, '').replace(/```/g, '');
      
      // Find JSON object in the response
      const jsonMatch = jsonString.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        jsonString = jsonMatch[0];
      }
      
      const parsed = JSON.parse(jsonString);
      
      // Validate and create candidate object
      return {
        id: Date.now().toString(),
        name: parsed.name || this.extractNameFromFilename(filename) || this.getFallbackName(filename),
        location: parsed.location || 'Location not specified',
        currentRole: parsed.currentRole || 'Professional',
        currentCompany: parsed.currentCompany || 'Company not specified',
        score: Math.max(1, Math.min(10, parsed.score || 6)),
        experiences: Array.isArray(parsed.experiences) ? parsed.experiences.slice(0, 5) : [
          {
            role: parsed.currentRole || 'Professional',
            company: parsed.currentCompany || 'Previous Company',
            period: '2022 - Present'
          }
        ],
        strengths: Array.isArray(parsed.strengths) ? parsed.strengths.slice(0, 6) : ['Relevant experience'],
        weaknesses: Array.isArray(parsed.weaknesses) ? parsed.weaknesses.slice(0, 4) : ['Areas for improvement'],
        recommendation: (['approve', 'hold', 'reject'].includes(parsed.recommendation)) 
          ? parsed.recommendation as RecommendationType 
          : 'hold'
      };
      
    } catch (error) {
      return this.enhancedRuleBasedParsing(filename, '', jd);
    }
  }

  private enhancedRuleBasedParsing(filename: string, text: string, jd: { mustHave: string; niceToHave: string }): Candidate {
    // Try to extract name from filename first
    let name = this.extractNameFromFilename(filename);
    
    // If filename is generic, try to extract name from text
    if (!name) {
      name = this.extractNameFromText(text) || this.getFallbackName(filename);
    }
    
    // Simple location detection
    const location = this.extractLocationFromText(text);
    
    // Role detection
    const currentRole = this.extractRoleFromText(text);
    
    // Skill detection and scoring
    const { skills, score, strengths, weaknesses, recommendation } = this.analyzeSkillsAndCreateProfile(text, jd);
    
    // Extract real experiences from text
    const experiences = this.extractExperiencesFromText(text, currentRole);
    
    return {
      id: Date.now().toString(),
      name,
      location,
      currentRole,
      currentCompany: experiences.length > 0 ? experiences[0].company : 'Company not specified',
      score,
      experiences,
      strengths,
      weaknesses,
      recommendation
    };
  }

  private extractNameFromFilename(filename: string): string | null {
    let name = filename.replace(/\.(pdf|docx|doc|txt)$/i, '').trim();
    
    // Remove common suffixes FIRST
    name = name.replace(/\s*(resume|cv)\s*$/i, '').trim();
    
    // Handle underscore-separated names like SAI_DIVYA_KANTA (BEFORE general replacement)
    if (name.includes('_') && name.split('_').every(part => part.length > 1) && name.split('_').length <= 4) {
      name = name.split('_').map(part => 
        part.charAt(0).toUpperCase() + part.slice(1).toLowerCase()
      ).join(' ');
    } else {
      // Handle other filename patterns only if not underscore pattern
      name = name.replace(/[_-]/g, ' '); // Replace underscores/hyphens
      name = name.replace(/([a-z])([A-Z])/g, '$1 $2'); // CamelCase
      name = name.replace(/\s+/g, ' ').trim(); // Normalize spaces
    }
    
    // Check if result is generic/invalid after cleanup
    const genericPatterns = [
      /^(my|updated|new|final|latest|current)$/i,
      /^(resume|cv|document)$/i,
      /^\d+$/,  // Only numbers
      /^(v\d+|version\d*)$/i,  // Version numbers
      /^(draft|temp|backup)$/i,
      /^[a-z]$/i  // Single letter
    ];
    
    const isGeneric = genericPatterns.some(pattern => pattern.test(name.trim()));
    
    if (isGeneric || name.length < 2) {
      return null; // Signal that we need to try text parsing
    }
    
    // Proper case formatting for valid names
    if (name === name.toUpperCase() || name === name.toLowerCase()) {
      name = name.toLowerCase().split(' ').map(word => 
        word.charAt(0).toUpperCase() + word.slice(1)
      ).join(' ');
    }
    
    return name || null;
  }

  private extractNameFromText(text: string): string | null {
    if (!text || text.length < 50) return null;
    
    // Look for name patterns in first few lines
    const lines = text.split(/\r?\n/).slice(0, 10).map(l => l.trim()).filter(Boolean);
    
    for (const line of lines) {
      // Pattern: 2-3 proper names (First Last or First Middle Last)
      const nameMatch = line.match(/^([A-Z][a-z]+(?:\s+[A-Z][a-z]*){1,2})$/);
      if (nameMatch && nameMatch[1].length >= 4 && nameMatch[1].length <= 40) {
        const candidateName = nameMatch[1];
        
        // Exclude lines that look like titles, companies, or technical terms
        const excludePatterns = [
          /\b(engineer|developer|manager|analyst|consultant|specialist|director|senior|junior|lead|architect|designer|coordinator)\b/i,
          /\b(software|technology|systems|solutions|services|company|corporation|ltd|inc|pvt)\b/i,
          /\b(email|phone|mobile|address|linkedin|github|portfolio)\b/i
        ];
        
        const isExcluded = excludePatterns.some(pattern => pattern.test(candidateName));
        if (!isExcluded) {
          return candidateName;
        }
      }
    }
    
    return null;
  }

  private getFallbackName(filename: string): string {
    // Generate a reasonable fallback name
    const cleanFilename = filename.replace(/\.pdf$/i, '').replace(/[_-]/g, ' ');
    
    if (cleanFilename.includes('resume') || cleanFilename.includes('cv')) {
      return 'Candidate ' + Date.now().toString().slice(-4); // e.g., "Candidate 1234"
    }
    
    return 'Name from ' + cleanFilename.substring(0, 20);
  }

  private extractLocationFromText(text: string): string {
    const cities = [
      'bangalore', 'mumbai', 'delhi', 'hyderabad', 'chennai', 'pune', 'kolkata',
      'gurugram', 'gurgaon', 'ahmedabad', 'jaipur', 'noida', 'kanpur'
    ];
    
    const lowerText = text.toLowerCase();
    for (const city of cities) {
      if (lowerText.includes(city)) {
        return city.charAt(0).toUpperCase() + city.slice(1);
      }
    }
    
    return 'Location not specified';
  }

  private extractRoleFromText(text: string): string {
    const rolePatterns = [
      { keywords: ['software engineer', 'software developer'], role: 'Software Engineer' },
      { keywords: ['frontend developer', 'front end'], role: 'Frontend Developer' },
      { keywords: ['backend developer', 'back end'], role: 'Backend Developer' },
      { keywords: ['full stack', 'fullstack'], role: 'Full Stack Developer' },
      { keywords: ['senior developer', 'senior engineer'], role: 'Senior Developer' },
      { keywords: ['lead developer', 'tech lead'], role: 'Technical Lead' },
      { keywords: ['data scientist', 'data analyst'], role: 'Data Scientist' }
    ];
    
    const lowerText = text.toLowerCase();
    for (const { keywords, role } of rolePatterns) {
      if (keywords.some(keyword => lowerText.includes(keyword))) {
        return role;
      }
    }
    
    return 'Software Professional';
  }

  private extractExperiencesFromText(text: string, defaultRole: string): Array<{role: string, company: string, period: string}> {
    const experiences: Array<{role: string, company: string, period: string}> = [];
    
    if (!text || text.length < 100) {
      // Fallback experience
      return [{
        role: defaultRole,
        company: 'Previous Company',
        period: '2022 - Present'
      }];
    }
    
    const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    
    // Look for company patterns
    const companyPatterns = [
      /(?:^|\s)((?:[A-Z][a-z]*\s*){1,3}(?:Technologies|Technology|Solutions|Systems|Software|Services|Corp|Corporation|Inc|Ltd|Pvt|Company|Group|Labs|Studio|Digital|Cloud|Data|AI|Consulting|Ventures|Development))\b/gi,
      /(?:^|\s)((?:TCS|Infosys|Wipro|Cognizant|HCL|Accenture|IBM|Microsoft|Google|Amazon|Oracle|SAP|Adobe|Dell|HP|Intel|Cisco|VMware|Salesforce|ServiceNow|Zoho))\b/gi,
      /(?:^|\s)((?:[A-Z][a-z]*\s*){1,2}(?:Infotech|Software|Solutions|Systems|Technologies))\b/gi
    ];
    
    // Look for role patterns  
    const rolePatterns = [
      /(?:^|\s)((?:Senior|Lead|Principal|Staff|Associate|Junior)?\s*(?:Software|Full[- ]?Stack|Frontend|Front[- ]?End|Backend|Back[- ]?End|Web|Mobile|Cloud|Data|DevOps|QA|Test)?\s*(?:Engineer|Developer|Architect|Analyst|Manager|Lead|Specialist|Consultant))/gi,
      /(?:^|\s)((?:Product|Project|Program|Technical|Engineering|Development|Team)\s*(?:Manager|Lead|Director|Head))/gi
    ];
    
    // Look for date patterns
    const datePatterns = [
      /(?:^|\s)((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4})\s*[-–—]\s*((?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4}|Present|Current|Till Date)/gi,
      /(?:^|\s)(\d{4})\s*[-–—]\s*(\d{4}|Present|Current)/gi,
      /(?:^|\s)(\d{1,2}\/\d{4})\s*[-–—]\s*(\d{1,2}\/\d{4}|Present|Current)/gi
    ];
    
    // Extract companies
    const foundCompanies: string[] = [];
    for (const pattern of companyPatterns) {
      const matches = text.match(pattern);
      if (matches) {
        foundCompanies.push(...matches.map(m => m.trim()));
      }
    }
    
    // Extract roles
    const foundRoles: string[] = [];
    for (const pattern of rolePatterns) {
      const matches = text.match(pattern);
      if (matches) {
        foundRoles.push(...matches.map(m => m.trim()));
      }
    }
    
    // Extract dates
    const foundDates: string[] = [];
    for (const pattern of datePatterns) {
      const matches = text.match(pattern);
      if (matches) {
        foundDates.push(...matches.map(m => m.trim()));
      }
    }
    
    // Extract companies, roles, and dates from text
    
    // Create experience entries by combining found data
    const maxExperiences = Math.min(3, Math.max(foundCompanies.length, foundRoles.length, 1));
    
    for (let i = 0; i < maxExperiences; i++) {
      const company = foundCompanies[i] || foundCompanies[0] || `Company ${i + 1}`;
      const role = foundRoles[i] || foundRoles[0] || defaultRole;
      const period = foundDates[i] || (i === 0 ? '2021 - Present' : `${2020 - i} - ${2021 - i}`);
      
      // Clean up the extracted data
      const cleanCompany = company.replace(/^(at|with|in)\s+/i, '').trim();
      const cleanRole = role.replace(/^(as|position|role)\s+/i, '').trim();
      
      experiences.push({
        role: cleanRole.substring(0, 50), // Limit length
        company: cleanCompany.substring(0, 30), // Limit length
        period: period.substring(0, 20) // Limit length
      });
    }
    
    // If no meaningful experiences found, create a basic one
    if (experiences.length === 0) {
      experiences.push({
        role: defaultRole,
        company: 'Previous Company',
        period: '2022 - Present'
      });
    }
    
    return experiences;
  }

  private analyzeSkillsAndCreateProfile(text: string, jd: { mustHave: string; niceToHave: string }) {
    const mustHaveSkills = jd.mustHave.toLowerCase().split(',').map(s => s.trim()).filter(Boolean);
    const niceToHaveSkills = jd.niceToHave.toLowerCase().split(',').map(s => s.trim()).filter(Boolean);
    
    const lowerText = text.toLowerCase();
    const foundMustHave = mustHaveSkills.filter(skill => lowerText.includes(skill));
    const foundNiceToHave = niceToHaveSkills.filter(skill => lowerText.includes(skill));
    const missingMustHave = mustHaveSkills.filter(skill => !lowerText.includes(skill));
    
    // Calculate score based on skill match
    const mustHaveMatch = foundMustHave.length / Math.max(mustHaveSkills.length, 1);
    const niceToHaveMatch = foundNiceToHave.length / Math.max(niceToHaveSkills.length, 1);
    const score = Math.round((mustHaveMatch * 7 + niceToHaveMatch * 3) * 10) / 10;
    
    // Generate strengths and weaknesses
    const strengths = ['Experience in software development'];
    if (foundMustHave.length > 0) {
      strengths.unshift(`Strong match for key skills: ${foundMustHave.join(', ')}`);
    }
    if (foundMustHave.length === mustHaveSkills.length) {
      strengths.unshift('✅ Meets all must-have requirements');
    }
    
    const weaknesses = [];
    if (missingMustHave.length > 0) {
      weaknesses.push(`Missing key skills: ${missingMustHave.join(', ')}`);
    }
    if (foundMustHave.length < mustHaveSkills.length * 0.5) {
      weaknesses.push('Limited experience in required technologies');
    }
    
    // Determine recommendation
    let recommendation: RecommendationType = 'hold';
    if (score >= 8.0 && missingMustHave.length <= 1) {
      recommendation = 'approve';
    } else if (score < 6.0 || missingMustHave.length > 2) {
      recommendation = 'reject';
    }
    
    return {
      skills: [...foundMustHave, ...foundNiceToHave],
      score: Math.max(4.0, score),
      strengths: strengths.slice(0, 6),
      weaknesses: weaknesses.length > 0 ? weaknesses : ['Areas for improvement based on job requirements'],
      recommendation
    };
  }
}