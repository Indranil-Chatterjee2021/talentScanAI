import React, { useState } from 'react';
import CustomerSuccessManager, { RecommendationType, Candidate } from './CustomerSuccessManager';
import JDResumeInput from './JDResumeInput';
import { AIResumeParser } from './aiResumeParser';
import './App.css';
import * as pdfjsLib from 'pdfjs-dist/build/pdf';
import 'pdfjs-dist/build/pdf.worker.entry';

interface JDState {
  mustHave: string;
  niceToHave: string;
}

function App() {
  const [jd, setJD] = useState<JDState>({ mustHave: '', niceToHave: '' });
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [jdSubmitted, setJDSubmitted] = useState(false);
  const [resumeFiles, setResumeFiles] = useState<File[]>([]);
  const [showToast, setShowToast] = useState(false);
  const [editingJD, setEditingJD] = useState(false);
  const [jdChangedSinceScan, setJDChangedSinceScan] = useState(false);



  const handleRecommendationChange = (candidateId: string, recommendation: RecommendationType) => {
    setCandidates(prevCandidates =>
      prevCandidates.map(candidate =>
        candidate.id === candidateId
          ? { ...candidate, recommendation }
          : candidate
      )
    );
  };

  // Step 1: Submit JD only
  const handleJDSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setJDSubmitted(true);
    setEditingJD(false);
    setShowToast(true);
    setJDChangedSinceScan(false);
    setTimeout(() => setShowToast(false), 3000);
    // Automatically rescan candidates if resumes are uploaded
    if (resumeFiles.length > 0) {
      await handleResumeUpload(resumeFiles);
    }
  };

  // Allow editing JD
  const handleEditJD = () => {
    setEditingJD(true);
  };

  // Track JD changes after initial submit
  const handleJDChange = (newJD: JDState) => {
    setJD(newJD);
    if (jdSubmitted) {
      setJDChangedSinceScan(true);
    }
  };

  // Helper to extract text from PDF using pdfjs-dist
  async function extractTextFromPDF(file: File): Promise<string> {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let text = '';
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      text += (content.items as { str?: string }[]).map(item => (item.str || '')).join(' ') + '\n';
    }
    return text;
  }

  // Helper function to enhance candidate scoring based on JD requirements
  // Removed enhanceCandidateWithJD - now handled by AI parser



  // Step 2: AI-Powered Resume Processing
  const handleResumeUpload = async (files: File[]) => {
    setResumeFiles(files);
    if (jdSubmitted && files.length > 0) {
      const candidates: Candidate[] = [];
      const aiParser = AIResumeParser.getInstance();
      
  
      
      for (const file of files) {
        try {
  
          
          // Extract text from different file types
          let extractedText = '';
          if (file.type === 'application/pdf') {
            extractedText = await extractTextFromPDF(file);
          } else if (file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || 
                     file.name.toLowerCase().endsWith('.docx')) {
            // Handle DOCX files
            try {
              const mammoth = await import('mammoth');
              const result = await mammoth.extractRawText({arrayBuffer: await file.arrayBuffer()});
              extractedText = result.value;
                      } catch (docxError) {
            extractedText = await file.text(); // Fallback
          }
          } else {
            extractedText = await file.text();
          }
          
          // Use AI parser to analyze the resume
          const candidate = await aiParser.parseResume(file.name, extractedText, jd);
          

          
          candidates.push(candidate);
          
        } catch (error) {
          
          // Fallback: Create basic candidate from filename
          const fallbackCandidate: Candidate = {
            id: Date.now().toString() + Math.random(),
            name: file.name.replace(/\.pdf$/i, '').replace(/[_-]/g, ' '),
            location: 'Location not specified',
            currentRole: 'Professional',
            currentCompany: 'Company not specified',
            score: 5.0,
            experiences: [{
              role: 'Professional',
              company: 'Previous Company',
              period: '2022 - Present'
            }],
            strengths: ['Resume uploaded successfully'],
            weaknesses: ['Parsing failed - manual review needed'],
            recommendation: 'hold'
          };
          
          candidates.push(fallbackCandidate);
        }
      }
      
      // Update candidates state
      setCandidates(prevCandidates => {
        const updated: Candidate[] = [...prevCandidates];
        candidates.forEach(newCand => {
          const idx = updated.findIndex(c => c.name === newCand.name);
          if (idx !== -1) {
            updated[idx] = { ...updated[idx], ...newCand };
          } else {
            updated.push(newCand);
          }
        });
        return updated;
      });
      
      setJDChangedSinceScan(false);

    }
  };

  // Rescan candidates after JD update
  const handleRescanCandidates = async () => {
    if (resumeFiles.length > 0) {
      // Use the same improved parsing logic as handleResumeUpload
      await handleResumeUpload(resumeFiles);
    }
    setEditingJD(false);
  };

  return (
    <div className="App">
      {showToast && (
        <div className="toast-success">JD submitted successfully!</div>
      )}
      

      
      <CustomerSuccessManager
        candidates={candidates}
        onRecommendationChange={handleRecommendationChange}
        onResumeUpload={handleResumeUpload}
        jdResumeSection={
          <JDResumeInput
            jd={jd}
            setJD={handleJDChange}
            onSubmit={handleJDSubmit}
            readonly={jdSubmitted && !editingJD}
            onEdit={handleEditJD}
            showRescan={jdChangedSinceScan && resumeFiles.length > 0}
            onRescan={handleRescanCandidates}
          />
        }
      />
    </div>
  );
}

export default App;