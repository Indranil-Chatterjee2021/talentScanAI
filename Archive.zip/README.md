# Resume Analysis System

A modern, AI-powered resume parsing and candidate evaluation system built with React, TypeScript, and Google Generative AI.

## 🚀 Features

- **AI-Powered Resume Parsing**: Uses Google Generative AI (Gemini) for intelligent text extraction
- **Multi-Format Support**: PDF, DOCX, DOC, TXT files
- **Smart Candidate Scoring**: Automatic skill matching and scoring based on job requirements
- **Professional UI**: Clean, modern interface with responsive design
- **Real-time Analysis**: Instant candidate evaluation and recommendations

## 📋 Prerequisites

- Node.js (v16 or higher)
- npm or yarn
- Google Generative AI API Key (optional, for enhanced AI features)

## 🛠️ Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd vibing-resume-parser
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   
   Create a `.env` file in the root directory:
   ```env
   REACT_APP_GOOGLE_AI_API_KEY=your_google_ai_api_key_here
   ```

## 🔑 API Key Setup

### Google Generative AI API Key

1. **Get API Key**:
   - Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
   - Create a new API key
   - Copy the key

2. **Add to Environment**:
   - Create `.env` file in project root
   - Add: `REACT_APP_GOOGLE_AI_API_KEY=your_key_here`

3. **Restart Application**:
   ```bash
   npm start
   ```

### Without API Key (Demo Mode)

The application works without an API key using enhanced rule-based parsing:
- ✅ Basic resume parsing
- ✅ Skill extraction
- ✅ Candidate scoring
- ⚠️ Limited AI intelligence

## 🚀 Running the Application

```bash
npm start
```

The application will open at `http://localhost:3000`

## 📖 Usage

1. **Enter Job Description**:
   - Add "Must Have" skills (e.g., AWS, NodeJS, React)
   - Add "Nice to Have" skills (e.g., GoLang, Python)
   - Click "Edit JD" to modify

2. **Upload Resumes**:
   - Click "Upload & Scan Resumes"
   - Select PDF, DOCX, DOC, or TXT files
   - Multiple files supported

3. **Review Results**:
   - View candidate information
   - Check scores and recommendations
   - Use approve/hold/reject buttons

## 🏗️ Project Structure

```
src/
├── App.tsx                 # Main application component
├── CustomerSuccessManager.tsx  # UI component for candidate display
├── JDResumeInput.tsx       # Job description input component
├── aiResumeParser.ts       # AI-powered resume parsing logic
├── sampleData.ts           # Sample data utilities
└── *.css                   # Styling files
```

## 🔧 Technical Details

### AI Integration
- **Primary**: Google Generative AI (Gemini Pro)
- **Fallback**: Enhanced rule-based parsing
- **Features**: Name extraction, skill analysis, experience parsing

### File Processing
- **PDF**: PDF.js library
- **DOCX**: Mammoth.js library
- **Text**: Native browser APIs

### Scoring Algorithm
- **Must-Have Skills**: 70% weight
- **Nice-to-Have Skills**: 30% weight
- **Final Score**: 0-10 scale

## 🐛 Troubleshooting

### Common Issues

1. **API Key Not Working**:
   - Verify key is correct
   - Check `.env` file location
   - Restart development server

2. **File Upload Issues**:
   - Ensure file format is supported
   - Check file size (max 10MB recommended)
   - Try different file formats

3. **Parsing Errors**:
   - Application falls back to rule-based parsing
   - Check console for specific errors
   - Verify file content is readable

## 📝 License

This project is licensed under the MIT License.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## 📞 Support

For issues and questions:
- Check the troubleshooting section
- Review console logs for errors
- Ensure all prerequisites are met